# VANTA Reporter

A starter Android application scaffold using Kotlin and Jetpack Compose.

## Build

With Gradle installed and Android SDK configured, run:

```bash
gradle :app:assembleDebug
```
